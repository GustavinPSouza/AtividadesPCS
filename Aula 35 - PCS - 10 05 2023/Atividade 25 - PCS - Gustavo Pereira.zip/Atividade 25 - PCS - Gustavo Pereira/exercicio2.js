 function exibirMensagem() {
            var nome = document.getElementById("nome").value;
            alert("Olá, " + nome + "! Bem-vindo(a)!");
        }