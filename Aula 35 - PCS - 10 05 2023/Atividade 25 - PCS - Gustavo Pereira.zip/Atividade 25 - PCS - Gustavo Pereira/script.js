

        function exibirMensagem() {
            var nome = document.getElementById("nome").value;
			var nomesdomeio = document.getElementById("nomesdomeio").value;
			var sobrenome = document.getElementById("sobrenome").value;
            alert("" + nome + ' ' + nomesdomeio + ' ' + sobrenome + "");
        }