var carro = {
	marca: "Nissan",
	modelo: "skyline r34",
	ano: 1999,
	cor: "Azul meia noite",
	informacoes() { 
		console.log("o carro é um " + this.marca + ", " + "Modelo " + this.modelo + ", " + "ano " + this.ano + ", " + "cor " + this.cor)
	}
	
}


